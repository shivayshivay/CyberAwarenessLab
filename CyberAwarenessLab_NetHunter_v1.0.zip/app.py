from flask import Flask, render_template, request, redirect, url_for
from datetime import datetime

app = Flask(__name__)

SCENARIOS = {
    "phishing": {
        "title": "Phishing Login",
        "icon": "🎣",
        "description": "A fake account-verification message leads the victim to a convincing login page.",
        "route": "/scenario/phishing"
    },
    "smishing": {
        "title": "Smishing SMS",
        "icon": "📱",
        "description": "A fraudulent SMS uses urgency and a suspicious link to manipulate the victim.",
        "route": "/scenario/smishing"
    },
    "vishing": {
        "title": "Vishing Call",
        "icon": "☎️",
        "description": "A fake support/bank caller attempts to obtain sensitive information through social engineering.",
        "route": "/scenario/vishing"
    },
    "botscam": {
        "title": "Bot Scam",
        "icon": "🤖",
        "description": "A scripted scam chatbot creates urgency and requests a fictional verification payment.",
        "route": "/scenario/botscam"
    },
    "upi": {
        "title": "UPI Scam",
        "icon": "💳",
        "description": "A fictional payment-request scenario demonstrates common payment manipulation techniques.",
        "route": "/scenario/upi"
    },
    "job": {
        "title": "Job Scam",
        "icon": "💼",
        "description": "A fake recruitment offer demonstrates advance-fee and identity-information risks.",
        "route": "/scenario/job"
    },
    "parcel": {
        "title": "Parcel Scam",
        "icon": "📦",
        "description": "A fake delivery notification uses a deadline and a small fictional fee.",
        "route": "/scenario/parcel"
    },
    "quishing": {
        "title": "QR Phishing",
        "icon": "🔳",
        "description": "A QR code points to this local training application and demonstrates QR-based social engineering.",
        "route": "/scenario/quishing"
    }
}

@app.context_processor
def globals_for_templates():
    return {"demo_notice": "THIS IS FOR DEMONSTRATION ONLY"}

@app.route("/")
def index():
    return render_template("index.html", scenarios=SCENARIOS)

@app.route("/scenario/<name>", methods=["GET", "POST"])
def scenario(name):
    if name not in SCENARIOS:
        return "Scenario not found", 404

    submitted = request.method == "POST"

    # Deliberately do not read, log, store, or transmit form values.
    # The POST simply demonstrates the victim action.
    return render_template(
        f"{name}.html",
        scenario=SCENARIOS[name],
        submitted=submitted,
        now=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    )

@app.route("/report")
def report():
    return render_template("report.html", scenarios=SCENARIOS)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
