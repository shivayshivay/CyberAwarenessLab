# Cyber Awareness Lab

A safe, realistic cyber-crime awareness simulator for classroom demonstrations.

## Safety design

This project intentionally does NOT:
- store submitted passwords, OTPs, card details, UPI PINs, or personal data
- send SMS, email, or voice calls
- perform real payments
- harvest credentials
- deploy malware
- provide an operational phishing kit

The scenarios are designed to demonstrate the victim experience and attack chain while keeping all data local and disposable.

## Included scenarios

- Phishing
- Smishing
- Vishing
- Bot scam
- UPI/payment scam
- Job scam
- Parcel scam
- QR phishing

## NetHunter / Kali setup

```bash
git clone <YOUR_REPOSITORY_URL>
cd CyberAwarenessLab

python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

python3 app.py
```

Open:

http://127.0.0.1:5000

For classroom exposure, after testing locally:

```bash
ngrok http 5000
```

Only expose the awareness simulator. Do not use this project to collect real credentials or personal information.

## Demo banner

Every scenario is clearly marked:

"THIS IS FOR DEMONSTRATION ONLY"

Submitted values are discarded and are never written to disk.
